<h1 class="centered_text">This is the admin menu.</h1>


<ul>
<li><a href="<?php echo site_url('access/add_new_user'); ?>">Add new user</a></li>
<li><a href="<?php echo site_url('access/admin_show_users'); ?>">Show users</a></li>
</ul>





<p>
<br>
<a href="<?php echo site_url('main'); ?>">Return to main page</a>
</p>
