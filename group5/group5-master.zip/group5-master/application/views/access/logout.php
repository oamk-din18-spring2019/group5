<h1>You are now logged out, bye bye.</h1>

<p>
<br>
<a href="<?php echo site_url('main'); ?>">Return to main page</a>
</p>
